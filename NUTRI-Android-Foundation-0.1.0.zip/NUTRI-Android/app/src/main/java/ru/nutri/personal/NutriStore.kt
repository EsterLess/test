package ru.nutri.personal

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.nutriDataStore by preferencesDataStore(name = "nutri_settings")

class NutriStore(private val context: Context) {
    private object Keys {
        val WATER = intPreferencesKey("water_ml")
        val WATER_GOAL = intPreferencesKey("water_goal_ml")
        val REMINDERS = booleanPreferencesKey("water_reminders")
        val ANIMATIONS = booleanPreferencesKey("animations_enabled")
    }

    val water = context.nutriDataStore.data.map { it[Keys.WATER] ?: 0 }
    val waterGoal = context.nutriDataStore.data.map { it[Keys.WATER_GOAL] ?: 2500 }
    val reminders = context.nutriDataStore.data.map { it[Keys.REMINDERS] ?: true }
    val animations = context.nutriDataStore.data.map { it[Keys.ANIMATIONS] ?: true }

    suspend fun addWater(amount: Int) {
        context.nutriDataStore.edit { prefs ->
            prefs[Keys.WATER] = ((prefs[Keys.WATER] ?: 0) + amount).coerceAtMost(10000)
        }
    }

    suspend fun setWaterGoal(value: Int) {
        context.nutriDataStore.edit { it[Keys.WATER_GOAL] = value.coerceIn(250, 10000) }
    }

    suspend fun setReminders(enabled: Boolean) {
        context.nutriDataStore.edit { it[Keys.REMINDERS] = enabled }
    }

    suspend fun setAnimations(enabled: Boolean) {
        context.nutriDataStore.edit { it[Keys.ANIMATIONS] = enabled }
    }
}
