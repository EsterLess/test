package ru.nutri.personal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Background = Color(0xFF0D1216)
private val Surface = Color(0xFF19231F)
private val Surface2 = Color(0xFF202C35)
private val Green = Color(0xFF83DDAA)
private val Muted = Color(0xFF9AABA2)
private val Blue = Color(0xFF7CC9EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = NutriStore(applicationContext)
        setContent {
            NutriTheme {
                NutriApp(store)
            }
        }
    }
}

private enum class Destination(val label: String) {
    HOME("Главная"), DIARY("Дневник"), SCANNER("Сканер"), AI("AI-питание"), PROFILE("Профиль")
}

@Composable
private fun NutriTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Green,
        onPrimary = Color(0xFF102018),
        secondary = Blue,
        background = Background,
        surface = Surface,
        onBackground = Color(0xFFF1F5F2),
        onSurface = Color(0xFFF1F5F2),
        surfaceVariant = Surface2,
        onSurfaceVariant = Muted
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun NutriApp(store: NutriStore) {
    val scope = rememberCoroutineScope()
    val water by store.water.collectAsState(initial = 0)
    val waterGoal by store.waterGoal.collectAsState(initial = 2500)
    val reminders by store.reminders.collectAsState(initial = true)
    val animations by store.animations.collectAsState(initial = true)
    var destination by remember { mutableStateOf(Destination.HOME) }

    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF121A1E), tonalElevation = 0.dp) {
                Destination.entries.forEach { item ->
                    val icon = when (item) {
                        Destination.HOME -> Icons.Outlined.Home
                        Destination.DIARY -> Icons.Outlined.MenuBook
                        Destination.SCANNER -> Icons.Outlined.QrCodeScanner
                        Destination.AI -> Icons.Outlined.AutoAwesome
                        Destination.PROFILE -> Icons.Outlined.Person
                    }
                    NavigationBarItem(
                        selected = destination == item,
                        onClick = { destination = item },
                        icon = { Icon(icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green,
                            selectedTextColor = Green,
                            indicatorColor = Color(0xFF294333),
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = destination,
            modifier = Modifier.padding(padding),
            transitionSpec = {
                if (animations) fadeIn() togetherWith fadeOut()
                else EnterTransition.None togetherWith ExitTransition.None
            },
            label = "screen-transition"
        ) { target ->
            when (target) {
                Destination.HOME -> HomeScreen(
                    water = water,
                    waterGoal = waterGoal,
                    onWater = { amount -> scope.launch { store.addWater(amount) } },
                    onNavigate = { destination = it }
                )
                Destination.DIARY -> DiaryScreen()
                Destination.SCANNER -> ScannerScreen()
                Destination.AI -> DietScreen()
                Destination.PROFILE -> ProfileScreen(
                    waterGoal = waterGoal,
                    reminders = reminders,
                    animations = animations,
                    onWaterGoal = { scope.launch { store.setWaterGoal(it) } },
                    onReminders = { scope.launch { store.setReminders(it) } },
                    onAnimations = { scope.launch { store.setAnimations(it) } }
                )
            }
        }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) { item { Column(verticalArrangement = Arrangement.spacedBy(16.dp), content = content) } }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier.size(42.dp).background(Color(0xFF203A31), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Outlined.EnergySavingsLeaf, null, tint = Green, modifier = Modifier.size(25.dp)) }
        Column {
            Text("NUTRI", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text("PERSONAL EDITION · RU", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
        }
        Spacer(Modifier.weight(1f))
        Surface(color = Color(0xFF203A31), shape = RoundedCornerShape(50)) {
            Text("BETA", color = Green, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HomeScreen(water: Int, waterGoal: Int, onWater: (Int) -> Unit, onNavigate: (Destination) -> Unit) {
    ScreenColumn {
        BrandHeader()
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("ТВОЙ ДЕНЬ", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Text("Питайся осознанно.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Маленькие шаги — большой результат.", color = Muted, fontSize = 13.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Калории сегодня", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("В пределах цели", color = Green, fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("1 240", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text(" / 2 200 ккал", color = Muted, modifier = Modifier.padding(bottom = 5.dp))
                }
                LinearProgressIndicator(progress = { 1240f / 2200f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Green, trackColor = Color(0xFF34423B))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Macro("БЕЛКИ", "68 г", "130 г", Green)
                    Macro("ЖИРЫ", "42 г", "70 г", Color(0xFFE5BE77))
                    Macro("УГЛЕВОДЫ", "125 г", "250 г", Blue)
                }
            }
        }
        Text("Быстрое добавление", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionCard("Фото еды", "Распознать блюдо", Icons.Outlined.PhotoCamera, Color(0xFF244535), Green, Modifier.weight(1f)) { onNavigate(Destination.SCANNER) }
            ActionCard("Штрихкод", "Найти продукт", Icons.Outlined.QrCodeScanner, Color(0xFF202C37), Blue, Modifier.weight(1f)) { onNavigate(Destination.SCANNER) }
        }
        WaterCard(water, waterGoal, onWater)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("План питания", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { onNavigate(Destination.AI) }) { Text("Открыть план", color = Green) }
                }
                MealRow("Завтрак", "Овсянка с ягодами", "380 ккал", Icons.Outlined.WbSunny)
                HorizontalDivider(color = Color(0xFF34413A))
                MealRow("Обед", "Гречка с курицей", "520 ккал", Icons.Outlined.LunchDining)
            }
        }
    }
}

@Composable
private fun Macro(title: String, value: String, target: String, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("из $target", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(142.dp), colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(27.dp))
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color(0xFFB2C1B8), fontSize = 10.sp)
            }
            Text("ОТКРЫТЬ  ↗", color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun WaterCard(water: Int, goal: Int, onWater: (Int) -> Unit) {
    val progress = (water.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17232B)), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.WaterDrop, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                Text("Водный баланс", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${(progress * 100).toInt()}%", color = Blue, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text("$water", color = Blue, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text(" / $goal мл", color = Muted, modifier = Modifier.padding(bottom = 4.dp))
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Blue, trackColor = Color(0xFF304653))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(150, 250, 500).forEach { amount ->
                    OutlinedButton(onClick = { onWater(amount) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Text("+$amount", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MealRow(title: String, subtitle: String, kcal: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = Color(0xFF2A3933), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Text(kcal, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
private fun DiaryScreen() {
    ScreenColumn {
        Text("Дневник питания", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("История и контроль рациона", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("СЕГОДНЯ", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                Text("1 240 ккал", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { 1240f / 2200f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Green)
                Text("Осталось 960 ккал до дневной цели", color = Muted, fontSize = 12.sp)
            }
        }
        listOf("Завтрак" to "Овсянка с ягодами · 380 ккал", "Обед" to "Гречка с курицей · 520 ккал", "Перекус" to "Творог с бананом · 340 ккал", "Ужин" to "Пока не добавлен").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(it.first, fontWeight = FontWeight.SemiBold); Text(it.second, color = Muted, fontSize = 12.sp) }
                    Icon(Icons.Outlined.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun ScannerScreen() {
    var mode by remember { mutableStateOf(0) }
    var code by remember { mutableStateOf("") }
    var showDemo by remember { mutableStateOf(false) }
    ScreenColumn {
        Text("Сканер продуктов", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Добавь еду в дневник", color = Muted)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            SegmentedButton(selected = mode == 0, onClick = { mode = 0 }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("Фото еды") }
            SegmentedButton(selected = mode == 1, onClick = { mode = 1 }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("Штрихкод") }
        }
        Card(colors = CardDefaults.cardColors(containerColor = if (mode == 0) Color(0xFF1D3028) else Color(0xFF202D37)), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Icon(if (mode == 0) Icons.Outlined.PhotoCamera else Icons.Outlined.QrCodeScanner, null, tint = if (mode == 0) Green else Blue, modifier = Modifier.size(54.dp))
                Text(if (mode == 0) "Анализ блюда по фото" else "Сканирование EAN-13", fontWeight = FontWeight.Bold)
                Text(if (mode == 0) "ИИ определит блюдо, ингредиенты и примерную массу. Результат можно будет проверить." else "Наведи камеру на штрихкод упаковки. Приложение найдёт продукт в базе.", color = Muted)
                if (mode == 1) OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Штрихкод вручную") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { showDemo = true }, modifier = Modifier.fillMaxWidth()) { Text(if (mode == 0) "Открыть камеру (следующий этап)" else "Проверить код (демо)") }
            }
        }
        if (showDemo) Text("Камера и реальное распознавание будут подключены на следующем этапе. Сейчас это каркас пользовательского сценария.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun DietScreen() {
    var goal by remember { mutableStateOf("Снижение веса") }
    var diet by remember { mutableStateOf("Без ограничений") }
    var budget by remember { mutableStateOf("Средний") }
    var time by remember { mutableStateOf("До 30 минут") }
    var meals by remember { mutableStateOf("4") }
    var exclusions by remember { mutableStateOf("") }
    var created by remember { mutableStateOf(false) }
    ScreenColumn {
        Text("AI Nutrition", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Персональный план питания", color = Muted)
        if (!created) {
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Составим рацион под тебя", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Question("Твоя цель", listOf("Снижение веса", "Поддержание веса", "Набор мышечной массы", "Здоровое питание"), goal) { goal = it }
                    HorizontalDivider(color = Color(0xFF34413A))
                    Question("Тип питания", listOf("Без ограничений", "Вегетарианское", "Без мяса", "Без молочных продуктов"), diet) { diet = it }
                    HorizontalDivider(color = Color(0xFF34413A))
                    Question("Бюджет", listOf("Экономный", "Средний", "Свободный"), budget) { budget = it }
                    HorizontalDivider(color = Color(0xFF34413A))
                    Question("Время на готовку", listOf("До 15 минут", "До 30 минут", "До 60 минут", "Не хочу готовить"), time) { time = it }
                    HorizontalDivider(color = Color(0xFF34413A))
                    Question("Приёмов пищи", listOf("2", "3", "4", "5"), meals) { meals = it }
                    OutlinedTextField(value = exclusions, onValueChange = { exclusions = it }, label = { Text("Аллергии и исключения") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Button(onClick = { created = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Сформировать рацион") }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Твой план питания", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("$goal · $diet · $budget", color = Green)
                    Text("$meals приёмов пищи · $time", color = Muted)
                    listOf("Завтрак" to "Овсянка с ягодами · 380 ккал", "Обед" to "Гречка с курицей · 520 ккал", "Перекус" to "Творог с фруктами · 250 ккал", "Ужин" to "Овощное рагу · 430 ккал").forEach { MealRow(it.first, it.second, "", Icons.Outlined.Restaurant) }
                    Text("Это демонстрационное меню. Реальный расчёт будет учитывать параметры тела, активность, ограничения и безопасность.", color = Muted, fontSize = 11.sp)
                    OutlinedButton(onClick = { created = false }, modifier = Modifier.fillMaxWidth()) { Text("Изменить ответы") }
                }
            }
            Text("Рецепты и подбор доставки подключим отдельными модулями после базового дневника и расчёта рациона.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Question(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        options.forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = selected == option, onClick = { onSelect(option) })
                Text(option, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    waterGoal: Int,
    reminders: Boolean,
    animations: Boolean,
    onWaterGoal: (Int) -> Unit,
    onReminders: (Boolean) -> Unit,
    onAnimations: (Boolean) -> Unit
) {
    var goalInput by remember(waterGoal) { mutableStateOf(waterGoal.toString()) }
    ScreenColumn {
        Text("Профиль и настройки", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Настрой приложение под себя", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Питание и цели", fontWeight = FontWeight.Bold)
                Text("Регион · Россия", color = Muted, fontSize = 13.sp)
                Text("Валюта · Российский рубль (₽)", color = Muted, fontSize = 13.sp)
                OutlinedTextField(value = goalInput, onValueChange = { goalInput = it.filter(Char::isDigit) }, label = { Text("Дневная цель воды, мл") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { goalInput.toIntOrNull()?.takeIf { it in 250..10000 }?.let(onWaterGoal) }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить цель воды") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Уведомления и интерфейс", fontWeight = FontWeight.Bold)
                SettingSwitch("Напоминания о воде", "Напоминать в течение дня", reminders, onReminders)
                HorizontalDivider(color = Color(0xFF34413A))
                SettingSwitch("Плавные анимации", "Переходы и эффекты интерфейса", animations, onAnimations)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Будущие подключения", fontWeight = FontWeight.Bold)
                Text("• Российские каталоги продуктов", color = Muted, fontSize = 13.sp)
                Text("• Камера и распознавание штрихкодов", color = Muted, fontSize = 13.sp)
                Text("• AI-анализ блюд и рецепты", color = Muted, fontSize = 13.sp)
                Text("• Сервисы доставки по адресу", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
